# Hatz Rollout Checklist

## Before Hatz build

- Confirm Hatz deployment type.
- Confirm who owns release approval.
- Confirm whether file uploads are allowed.
- Confirm whether summaries are stored.
- Confirm pilot group.
- Confirm no estimating or customer-commitment automation is included.

## During Hatz build

- Preserve source package.
- Preserve output contract.
- Keep human review gate visible.
- Add evidence folders or equivalent records.
- Run smoke tests.
- Run QA pack.

## Before controlled rollout

- QA complete.
- Issue log reviewed.
- Pilot run complete.
- Readiness scorecard complete.
- Go/no-go record signed by release owner.
