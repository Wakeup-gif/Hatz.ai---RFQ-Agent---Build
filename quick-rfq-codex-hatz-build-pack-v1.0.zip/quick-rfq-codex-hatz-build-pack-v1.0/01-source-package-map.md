# Source Package Map

## Source of truth

The source package is:

```text
source/quick-rfq-summary-app-v1.5/
```

## Live app files

These are the files that define the deployed assistant behavior.

| File | Role |
|---|---|
| `01-builder-fields.md` | App-builder metadata, description, starters, opening message, and capability posture. |
| `02-runtime-instructions.md` | Main live instruction field. Defines role, authority boundaries, source/evidence rules, status behavior, and RFQ-specific checks. |
| `03-output-contract.md` | Required 11-section RFQ Intake Summary output structure. |

Only these files should be pasted into the live builder/runtime unless a downstream owner explicitly approves a change.

## Product framework files

These files explain the product architecture and should guide implementation, QA, and future patches.

| File | Role |
|---|---|
| `13-rfq-product-framework-map.md` | Overall RFQ product structure and product flow. |
| `14-status-decision-framework.md` | Structural status selection model for Ready / Needs Clarification / Stop. |
| `15-missing-info-classification-framework.md` | Classification model for critical vs helpful vs conflicting gaps. |
| `16-scope-decomposition-framework.md` | Method for separating signage, millwork, install, service, electrical, revisions, and item-level scope. |
| `17-source-evidence-framework.md` | Evidence rules for reviewed content, referenced-but-not-reviewed sources, and non-evidence. |

## Deployment and operations files

| File | Role |
|---|---|
| `00-readme-handoff-guide.md` | Human-facing package overview and use status. |
| `08-deployment-checklist.md` | Setup and deployment checklist. |
| `18-builder-copy-paste-deployment-pack.md` | Single-copy deployment reference for builder setup. |
| `23-smoke-test-script.md` | Immediate post-deployment smoke tests. |

## QA, pilot, and release files

| File | Role |
|---|---|
| `04-qa-test-pack.md` | Full QA test set. |
| `05-qa-runner-and-patch-control.md` | QA runner format and patch control. |
| `19-qa-execution-sheet.md` | QA execution tracking sheet. |
| `24-qa-issue-log.md` | Issue tracking during QA. |
| `25-qa-evidence-record-template.md` | QA evidence record template. |
| `06-internal-pilot-playbook.md` | Internal pilot plan. |
| `07-pilot-summary-report-template.md` | Pilot report form. |
| `20-pilot-feedback-form.md` | Individual reviewer feedback form. |
| `21-readiness-scorecard.md` | Readiness scoring. |
| `26-pilot-sample-selection-guide.md` | How to select real pilot RFQs. |
| `27-pilot-run-sheet.md` | Pilot run tracker. |
| `28-go-no-go-decision-record.md` | Controlled use approval record. |
| `29-controlled-rollout-notes.md` | Controlled rollout guidance. |

## Governance files

| File | Role |
|---|---|
| `09-version-control-and-changelog-policy.md` | Versioning, patch, freeze, and rollback policy. |
| `12-v1.5-release-notes.md` | Current release notes. |
| `22-v1.5-build-log.md` | Current build log. |
| `manifest.json` | Source package file inventory and hashes. |
