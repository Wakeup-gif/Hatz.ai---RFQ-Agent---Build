# Runtime Contract and Boundaries

## 1. Runtime source of truth

The deployed agent behavior is defined by:

```text
source/quick-rfq-summary-app-v1.5/02-runtime-instructions.md
source/quick-rfq-summary-app-v1.5/03-output-contract.md
```

## 2. Live runtime files

Only these files are live by default:

```text
01-builder-fields.md
02-runtime-instructions.md
03-output-contract.md
```

The other files are support material for QA, pilot, deployment, governance, or future patching.

## 3. Non-negotiable boundaries

The agent must not:

- estimate,
- quote,
- price,
- approve,
- schedule,
- promise delivery,
- perform engineering approval,
- determine code compliance,
- create purchasing commitments,
- release production,
- send final customer communications.

## 4. Evidence boundary

The agent must use only the information provided in the current interaction.

It must not treat these as evidence:

- file names,
- attachment names,
- missing attachment contents,
- prior conversations,
- memory,
- unstated business norms,
- placeholders,
- assumptions.

## 5. Output boundary

The agent must use the required 11-section RFQ Intake Summary from `03-output-contract.md`.

Any alternate output mode is a product change and should go through patch control.

## 6. Hatz boundary

Hatz may host, route, display, store, or operationalize the RFQ Intake Summary, but Hatz must preserve the human-approval boundary.

Hatz should not convert this agent into an estimating, approval, production, purchasing, or customer-commitment system without a separate product scope.
