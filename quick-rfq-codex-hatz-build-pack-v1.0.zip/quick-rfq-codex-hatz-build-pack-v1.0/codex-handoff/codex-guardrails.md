# Codex Guardrails

## Must preserve

- Current-interaction-only evidence.
- Reviewed vs referenced-but-not-reviewed source distinction.
- File names and attachment names are not evidence.
- 11-section RFQ Intake Summary.
- Human review gate.
- No estimating/pricing/approval/scheduling authority.

## Must avoid

- Inferring hidden file contents.
- Adding CRM/email automation as default behavior.
- Sending customer communications.
- Adding quote generation.
- Adding production workflow release.
- Treating pilot/QA templates as completed evidence.

## Change rule

If implementation requires changing the product behavior, create a change request instead of silently editing source behavior.
