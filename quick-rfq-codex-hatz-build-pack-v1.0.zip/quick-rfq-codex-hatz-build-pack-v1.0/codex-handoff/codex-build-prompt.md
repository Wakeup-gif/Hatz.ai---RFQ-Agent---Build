# Codex Build Prompt

You are helping build the Quick RFQ Summary Agent from a source package.

Use this package as the source of truth:

```text
source/quick-rfq-summary-app-v1.5/
```

Your job is to create an implementation scaffold that preserves the product boundaries and prepares the agent for Hatz translation.

Read these files first:

```text
00-readme-codex-hatz-handoff.md
01-source-package-map.md
02-product-build-brief.md
03-agent-architecture-outline.md
04-codex-task-plan.md
05-repo-scaffold-plan.md
06-runtime-contract-and-boundaries.md
07-validation-handoff.md
08-open-questions-and-decision-log.md
```

Then inspect the source package files, especially:

```text
source/quick-rfq-summary-app-v1.5/01-builder-fields.md
source/quick-rfq-summary-app-v1.5/02-runtime-instructions.md
source/quick-rfq-summary-app-v1.5/03-output-contract.md
source/quick-rfq-summary-app-v1.5/04-qa-test-pack.md
source/quick-rfq-summary-app-v1.5/13-rfq-product-framework-map.md
source/quick-rfq-summary-app-v1.5/14-status-decision-framework.md
source/quick-rfq-summary-app-v1.5/15-missing-info-classification-framework.md
source/quick-rfq-summary-app-v1.5/16-scope-decomposition-framework.md
source/quick-rfq-summary-app-v1.5/17-source-evidence-framework.md
```

Build goal:

Create a clean repo scaffold for a Quick RFQ Summary Agent with a Hatz adapter placeholder, validation harness placeholders, and evidence folders.

Do not add estimating, pricing, approval, scheduling, production, purchasing, compliance, or customer-commitment behavior.

Do not change the app's output structure unless the source package is changed through patch control.

Do not claim QA, pilot, or deployment success unless evidence files are actually completed.
