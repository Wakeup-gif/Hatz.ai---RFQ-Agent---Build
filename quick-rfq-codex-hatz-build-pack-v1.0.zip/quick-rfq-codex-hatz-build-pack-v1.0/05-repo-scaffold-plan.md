# Repo Scaffold Plan

## Recommended repo name

```text
quick-rfq-summary-agent
```

## Scaffold

```text
quick-rfq-summary-agent/
  README.md
  docs/
    source-package/
      quick-rfq-summary-app-v1.5/
    product/
      product-build-brief.md
      rfq-product-framework-map.md
      status-decision-framework.md
      missing-info-classification-framework.md
      scope-decomposition-framework.md
      source-evidence-framework.md
    deployment/
      builder-copy-paste-deployment-pack.md
      deployment-checklist.md
      hatz-translation-brief.md
  app/
    __init__.py
    adapters/
      __init__.py
      cli_adapter.py
      hatz_adapter.py
    core/
      __init__.py
      input_capture.py
      source_evidence.py
      scope_decomposition.py
      missing_info.py
      status_decision.py
      human_review_gate.py
    contracts/
      __init__.py
      runtime_contract.py
      output_contract.py
    validation/
      __init__.py
      qa_runner.py
      smoke_runner.py
  tests/
    smoke/
      README.md
    qa-pack/
      README.md
  evidence/
    qa-runs/
    pilot-runs/
    issues/
    release-decisions/
  scripts/
    README.md
```

## Structural notes

The scaffold is intentionally modular, but the source package remains the authority.

Files under `app/core/` should not independently redefine product rules without traceability back to the source package.

## Non-goals

The scaffold does not require a specific framework, cloud provider, database, queue, UI, or deployment platform.

Those choices belong to downstream implementation.
