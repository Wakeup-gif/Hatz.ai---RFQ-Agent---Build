# Agent Architecture Outline

## 1. Architectural goal

Provide a clean implementation shape for the Quick RFQ Summary App while keeping product rules anchored to the v1.5 source package.

## 2. Recommended components

```text
User input
  ↓
Interface adapter
  ↓
Input capture / normalization
  ↓
Source and evidence gate
  ↓
Scope decomposition helper
  ↓
Missing/conflicting information classifier
  ↓
Status decision helper
  ↓
Output contract renderer
  ↓
Human review gate
  ↓
QA / evidence logging
```

## 3. Component boundaries

### Interface adapter

Owns:

- receiving pasted RFQ text,
- passing user input into the agent,
- returning the final RFQ Intake Summary.

Does not own:

- RFQ behavior rules,
- status-selection changes,
- pricing or workflow decisions.

### Input capture / normalization

Owns:

- preserving user-provided content,
- avoiding unsupported assumptions,
- passing raw input forward.

Does not own:

- adding facts,
- inferring missing attachment contents,
- converting ambiguous dates unless source input supports it.

### Source and evidence gate

Owns:

- reviewed content vs referenced-but-not-reviewed distinction,
- file-name-only trap prevention,
- current-interaction-only evidence rules.

Source of truth:

- `17-source-evidence-framework.md`
- `02-runtime-instructions.md`
- `03-output-contract.md`

### Scope decomposition helper

Owns:

- item grouping,
- shared project facts,
- separated signage/millwork/install/service/revision scopes.

Source of truth:

- `16-scope-decomposition-framework.md`

### Missing/conflicting information classifier

Owns:

- critical vs helpful vs conflicting gap separation.

Source of truth:

- `15-missing-info-classification-framework.md`

### Status decision helper

Owns:

- structural support for Ready / Needs Clarification / Stop.

Source of truth:

- `14-status-decision-framework.md`

### Output contract renderer

Owns:

- the exact 11-section RFQ Intake Summary format.

Source of truth:

- `03-output-contract.md`

### Human review gate

Owns:

- making the final boundary visible in output and workflow.

Does not own:

- human approval itself.

## 4. Implementation note

Codex may choose different module names, but it should preserve these boundaries unless a downstream owner explicitly changes the architecture.
