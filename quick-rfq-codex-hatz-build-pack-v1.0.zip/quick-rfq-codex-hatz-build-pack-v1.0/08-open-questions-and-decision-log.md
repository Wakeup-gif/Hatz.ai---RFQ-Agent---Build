# Open Questions and Decision Log

## 1. Open structural questions

These should be answered before full Hatz deployment.

| Question | Why it matters | Owner |
|---|---|---|
| What exactly is Hatz in this deployment: GPT wrapper, internal app, workflow platform, or agent host? | Determines adapter shape. | Product/build owner |
| Will users paste text only, upload files, or both? | Determines file handling and evidence policy implementation. | Product/build owner |
| If uploads are allowed, who extracts readable text from files? | The app must not infer unreadable attachment contents. | Build owner |
| Should RFQ summaries be stored? | Affects data retention, privacy, and audit logs. | Business/system owner |
| Who is release owner for go/no-go? | Required for pilot completion. | Business owner |
| What is the first controlled rollout group? | Needed for rollout notes. | Business owner |
| Should Hatz integrate with CRM, email, or job folders later? | Out of current scope, but affects future architecture. | Product owner |

## 2. Current assumptions

- Hatz is the target business/agent environment.
- Codex will help build a repository or implementation scaffold.
- The v1.5 package remains the product source of truth.
- Human review remains mandatory.
- File upload content is usable only if readable text is provided to the agent.

## 3. Decisions already settled

| Decision | Status |
|---|---|
| App does not estimate, price, approve, schedule, purchase, release, or send commitments. | Settled |
| Live app files are `01`, `02`, and `03`. | Settled |
| Output format is the 11-section RFQ Intake Summary. | Settled |
| QA and pilot evidence are required before broad internal use. | Settled |
