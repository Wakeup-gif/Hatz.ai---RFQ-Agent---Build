# Validation Handoff

## 1. Validation source files

Use these files from the source package:

```text
04-qa-test-pack.md
05-qa-runner-and-patch-control.md
19-qa-execution-sheet.md
23-smoke-test-script.md
24-qa-issue-log.md
25-qa-evidence-record-template.md
26-pilot-sample-selection-guide.md
27-pilot-run-sheet.md
28-go-no-go-decision-record.md
```

## 2. Required validation order

```text
Deployment setup
  ↓
Smoke tests
  ↓
Full QA pack
  ↓
Issue log
  ↓
Patch only observed failures
  ↓
Retest
  ↓
Pilot sample selection
  ↓
Pilot execution
  ↓
Readiness scorecard
  ↓
Go/no-go decision
```

## 3. Evidence requirements

Do not mark the product as broadly ready until evidence exists for:

- smoke test execution,
- QA execution,
- issue disposition,
- pilot run,
- reviewer feedback,
- readiness scorecard,
- go/no-go decision.

## 4. Codex testing guidance

Codex may scaffold tests from the QA pack, but passing automated tests is not the same as human pilot approval.

The app is designed for internal RFQ intake support and requires human review before operational use.
