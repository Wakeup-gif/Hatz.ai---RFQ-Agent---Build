# Codex Task Plan

## 1. Build mode

Target mode:

```text
Codex-supported implementation prep
```

Codex should use the source package as product authority and this package as the build handoff.

## 2. First Codex task

Create a repository scaffold that separates:

- source prompt/package files,
- runtime/agent code,
- output contract,
- validation tests,
- Hatz adapter,
- evidence records,
- docs.

Use `05-repo-scaffold-plan.md`.

## 3. Suggested task sequence

### Task 1 — Repo scaffold

Create the folder structure from `05-repo-scaffold-plan.md`.

Do not implement business logic yet.

### Task 2 — Source ingestion

Place the v1.5 package under:

```text
docs/source-package/quick-rfq-summary-app-v1.5/
```

Treat it as read-only source material.

### Task 3 — Runtime contract module

Create a runtime contract representation that references:

- `02-runtime-instructions.md`
- `03-output-contract.md`

Do not rewrite the app behavior unless the source package changes.

### Task 4 — Agent adapter skeleton

Create an agent adapter skeleton with clear boundaries for:

- input capture,
- evidence/source handling,
- scope decomposition,
- missing information classification,
- status decision support,
- output rendering,
- human review gate.

Implementation detail is deferred to Codex/build owner.

### Task 5 — Hatz adapter skeleton

Create a Hatz-facing adapter layer that maps the Quick RFQ agent into Hatz naming, routing, and deployment conventions.

Use:

```text
hatz-translation/hatz-agent-translation-brief.md
```

### Task 6 — Test harness scaffold

Create test harness placeholders using:

- `04-qa-test-pack.md`
- `23-smoke-test-script.md`
- `19-qa-execution-sheet.md`

Do not claim QA passed until tests are executed and evidence is recorded.

### Task 7 — Evidence and release folders

Create folders for:

- QA runs,
- pilot runs,
- issue logs,
- go/no-go records.

### Task 8 — Build README

Write a developer README explaining:

- source package authority,
- runtime boundaries,
- how to run tests,
- how to record evidence,
- how to deploy or translate into Hatz.

## 4. Codex constraints

Codex must not add:

- estimating,
- pricing,
- approval,
- scheduling,
- compliance determinations,
- production release,
- purchasing,
- customer-send behavior,
- undocumented data retention,
- unsupported file-reading assumptions.

## 5. Done condition for the Codex prep pass

The Codex prep pass is complete when:

- repo scaffold exists,
- source package is preserved,
- agent/hatz adapter skeletons exist,
- test/evidence folders exist,
- runtime/output contract is represented,
- no unauthorized business authority has been added.
