# Quick RFQ Summary App — Codex + Hatz Build Handoff v1.0

## 1. Purpose

This package prepares the **Quick RFQ Summary App v1.5** for downstream build support in Codex and translation into the Hatz environment.

The source package remains the authority:

```text
source/quick-rfq-summary-app-v1.5/
```

The implementation handoff material is supportive. If any handoff note conflicts with the v1.5 source package, use the source package.

Generated UTC: `2026-06-17T13:07:40Z`

## 2. Handoff target

Primary downstream target:

```text
Codex-supported implementation
```

Secondary downstream target:

```text
Hatz translation / deployment alignment
```

## 3. What this handoff covers

This handoff covers:

- product purpose and boundaries,
- source package map,
- agent architecture outline,
- Codex task plan,
- repo scaffold plan,
- Hatz translation map,
- runtime/output contract boundaries,
- QA and pilot validation handoff,
- open structural questions.

## 4. What this handoff does not cover

This handoff does not decide or implement:

- pricing,
- estimating,
- scheduling,
- production release,
- purchasing,
- customer-facing commitments,
- final UI design,
- backend data model,
- file-storage policy,
- authentication,
- deployment infrastructure,
- runtime state machine,
- recovery behavior,
- full implementation code.

Those remain downstream build or product decisions.

## 5. Package structure

```text
quick-rfq-codex-hatz-build-pack-v1.0/
  00-readme-codex-hatz-handoff.md
  01-source-package-map.md
  02-product-build-brief.md
  03-agent-architecture-outline.md
  04-codex-task-plan.md
  05-repo-scaffold-plan.md
  06-runtime-contract-and-boundaries.md
  07-validation-handoff.md
  08-open-questions-and-decision-log.md
  codex-handoff/
  hatz-translation/
  repo-scaffold/
  source/
  manifest.json
```

## 6. Recommended use

1. Read this README.
2. Read `01-source-package-map.md`.
3. Give Codex `codex-handoff/codex-build-prompt.md`.
4. Use `05-repo-scaffold-plan.md` to create the repo structure.
5. Use `06-runtime-contract-and-boundaries.md` to prevent unauthorized product expansion.
6. Use `hatz-translation/hatz-agent-translation-brief.md` before adapting the agent into Hatz.
7. Run smoke tests and QA from the source package before pilot use.

## 7. Current readiness

Package is ready for implementation-prep handoff.

It is not approved for broad internal production use until QA and pilot evidence are completed.
