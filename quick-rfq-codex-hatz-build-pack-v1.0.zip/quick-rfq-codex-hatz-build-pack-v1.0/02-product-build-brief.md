# Product Build Brief

## Product name

Quick RFQ Summary App

## Job to be done

Turn messy sign and millwork RFQ input into a consistent internal RFQ Intake Summary that helps a human estimator, PM, or intake user understand:

- what was requested,
- what is known,
- what is missing,
- what is unclear or conflicting,
- which sources were actually reviewed,
- what must be handled by a human.

## Core user

Primary users:

- estimator,
- project manager,
- intake/admin coordinator,
- internal RFQ reviewer.

## Inputs

The app may receive:

- pasted customer emails,
- RFQ text,
- internal project notes,
- drawing summaries,
- sign schedule text,
- readable attachment text,
- transcribed file content,
- requote/revision/addendum notes,
- mixed signage and millwork scope.

## Output

The app returns the required 11-section RFQ Intake Summary from `03-output-contract.md`.

## Product boundary

The app prepares, checks, organizes, and drafts.

Humans approve, decide, send, buy, schedule, release, and commit.

The agent must not:

- estimate,
- price,
- approve,
- schedule,
- engineer,
- produce compliance determinations,
- purchase,
- release work,
- make customer commitments.

## Build objective

Build an agent implementation or Hatz-compatible agent layer that faithfully executes the Quick RFQ v1.5 package without broadening its authority.
